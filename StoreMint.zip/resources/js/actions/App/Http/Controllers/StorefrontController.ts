import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StorefrontController::index
 * @see app/Http/Controllers/StorefrontController.php:17
 * @route '/'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
export const shop = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shop.url(options),
    method: 'get',
})

shop.definition = {
    methods: ["get","head"],
    url: '/shop',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
shop.url = (options?: RouteQueryOptions) => {
    return shop.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
shop.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shop.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
shop.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: shop.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
    const shopForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: shop.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
        shopForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: shop.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StorefrontController::shop
 * @see app/Http/Controllers/StorefrontController.php:25
 * @route '/shop'
 */
        shopForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: shop.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    shop.form = shopForm
const StorefrontController = { index, shop }

export default StorefrontController